document.addEventListener('DOMContentLoaded', function() {
    // Handle QR code payment confirmation
    const confirmPaymentBtn = document.getElementById('confirm-payment');
    if (confirmPaymentBtn) {
        confirmPaymentBtn.addEventListener('click', function() {
            const bookingId = this.dataset.bookingId;
            fetch(`/booking/${bookingId}/confirm-payment`, {
                method: 'POST',
            }).then(response => {
                if (response.ok) {
                    window.location.href = '/user/dashboard';
                }
            });
        });
    }

    // Validate booking time slots
    const bookingForm = document.getElementById('booking-form');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            const startTime = new Date(document.getElementById('start_time').value);
            const endTime = new Date(document.getElementById('end_time').value);
            
            if (startTime >= endTime) {
                e.preventDefault();
                alert('End time must be after start time');
            }
        });
    }
});
