from flask import render_template, redirect, url_for, flash, request, abort, send_file
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime
from app import app, db
from models import User, Turf, Booking
import qrcode
import io
import base64
import logging

@app.route('/')
def index():
    search_query = request.args.get('search', '')
    query = Turf.query.filter_by(is_available=True)

    if search_query:
        search_terms = f"%{search_query}%"
        query = query.filter(
            db.or_(
                Turf.name.ilike(search_terms),
                Turf.location.ilike(search_terms)
            )
        )

    turfs = query.all()
    return render_template('base.html', turfs=turfs)

# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            user = User.query.filter_by(email=request.form['email']).first()
            if user and user.check_password(request.form['password']):
                login_user(user)
                return redirect(url_for('dashboard'))
            flash('Invalid email or password')
        except Exception as e:
            logging.error(f"Login error: {str(e)}")
            flash('An error occurred during login. Please try again.')
    return render_template('auth/login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            # Check if username or email already exists
            existing_user = User.query.filter_by(username=request.form['username']).first()
            if existing_user:
                flash('Username already exists. Please choose a different username.')
                return render_template('auth/register.html')

            existing_email = User.query.filter_by(email=request.form['email']).first()
            if existing_email:
                flash('Email already registered. Please use a different email.')
                return render_template('auth/register.html')

            user = User(
                username=request.form['username'],
                email=request.form['email'],
                role=request.form['role']
            )
            user.set_password(request.form['password'])
            db.session.add(user)
            db.session.commit()
            login_user(user)
            flash('Registration successful!')
            return redirect(url_for('dashboard'))
        except Exception as e:
            logging.error(f"Registration error: {str(e)}")
            db.session.rollback()
            flash('An error occurred during registration. Please try again.')
    return render_template('auth/register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# Dashboard routes
@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'admin':
        return redirect(url_for('admin_dashboard'))
    elif current_user.role == 'owner':
        return redirect(url_for('owner_dashboard'))
    return redirect(url_for('user_dashboard'))

@app.route('/user/dashboard')
@login_required
def user_dashboard():
    if current_user.role != 'user':
        abort(403)
    bookings = Booking.query.filter_by(user_id=current_user.id).all()
    return render_template('user/dashboard.html', bookings=bookings)

@app.route('/owner/dashboard')
@login_required
def owner_dashboard():
    if current_user.role != 'owner':
        abort(403)
    try:
        turfs = Turf.query.filter_by(owner_id=current_user.id).all()
        # Get all bookings for the owner's turfs
        bookings = []
        for turf in turfs:
            turf_bookings = Booking.query.filter_by(turf_id=turf.id).all()
            bookings.extend(turf_bookings)
        return render_template('owner/dashboard.html', turfs=turfs, bookings=bookings, now=datetime.utcnow())
    except Exception as e:
        logging.error(f"Owner dashboard error: {str(e)}")
        flash('An error occurred while loading the dashboard.')
        return redirect(url_for('index'))

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.role != 'admin':
        abort(403)
    try:
        # Create admin user if it doesn't exist
        admin = User.query.filter_by(role='admin').first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@example.com',
                role='admin'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            flash('Admin account created with email: admin@example.com and password: admin123')

        users = User.query.all()
        turfs = Turf.query.all()
        bookings = Booking.query.all()
        return render_template('admin/dashboard.html', users=users, turfs=turfs, bookings=bookings)
    except Exception as e:
        logging.error(f"Admin dashboard error: {str(e)}")
        flash('An error occurred while loading the dashboard.')
        return redirect(url_for('index'))

# Turf management routes
@app.route('/turf/new', methods=['GET', 'POST'])
@login_required
def new_turf():
    if current_user.role != 'owner':
        abort(403)
    try:
        if request.method == 'POST':
            if not current_user.platform_fee_paid:
                flash('Please pay the platform fee first')
                return redirect(url_for('new_turf'))

            photo = request.files.get('photo')
            payment_qr = request.files.get('payment_qr')

            if not (photo and payment_qr):
                flash('Both turf photo and payment QR code are required')
                return redirect(url_for('new_turf'))

            # Validate file types
            allowed_types = {'image/jpeg', 'image/png'}
            if photo.content_type not in allowed_types or payment_qr.content_type not in allowed_types:
                flash('Only JPEG and PNG files are allowed')
                return redirect(url_for('new_turf'))

            turf = Turf(
                name=request.form['name'],
                description=request.form['description'],
                location=request.form['location'],
                price_per_hour=float(request.form['price']),
                owner_id=current_user.id,
                is_available='is_available' in request.form
            )

            # Save the files
            try:
                turf.photo = photo.read()
                turf.photo_type = photo.content_type
                turf.payment_qr = payment_qr.read()

                db.session.add(turf)
                db.session.commit()
                flash('Turf added successfully!')
                return redirect(url_for('owner_dashboard'))
            except Exception as e:
                logging.error(f"File upload error: {str(e)}")
                db.session.rollback()
                flash('Error uploading files. Please try again.')
                return redirect(url_for('new_turf'))

        # Generate UPI QR code for platform fee
        try:
            upi_qr = qrcode.QRCode(version=1, box_size=10, border=5)
            upi_qr.add_data("upi://pay?pa=arekarmandar1107-2@okaxis&pn=Platform Fee&am=200.00")
            upi_qr.make(fit=True)
            upi_img = upi_qr.make_image(fill_color="black", back_color="white")

            buffered = io.BytesIO()
            upi_img.save(buffered)
            upi_qr_code = f"data:image/png;base64,{base64.b64encode(buffered.getvalue()).decode()}"

            return render_template('turf/details.html', upi_qr_code=upi_qr_code)
        except Exception as e:
            logging.error(f"QR code generation error: {str(e)}")
            flash('Error generating QR code. Please try again.')
            return redirect(url_for('owner_dashboard'))

    except Exception as e:
        logging.error(f"New turf error: {str(e)}")
        db.session.rollback()
        flash('An error occurred while creating the turf. Please try again.')
        return redirect(url_for('owner_dashboard'))

@app.route('/turf/<int:turf_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_turf(turf_id):
    turf = Turf.query.get_or_404(turf_id)
    if current_user.id != turf.owner_id:
        abort(403)

    if request.method == 'POST':
        turf.name = request.form['name']
        turf.description = request.form['description']
        turf.location = request.form['location']
        turf.price_per_hour = float(request.form['price'])
        turf.is_available = 'is_available' in request.form

        photo = request.files.get('photo')
        if photo:
            turf.photo = photo.read()
            turf.photo_type = photo.content_type

        payment_qr = request.files.get('payment_qr')
        if payment_qr:
            turf.payment_qr = payment_qr.read()

        db.session.commit()
        flash('Turf updated successfully!')
        return redirect(url_for('owner_dashboard'))

    return render_template('turf/details.html', turf=turf)

@app.route('/turf/<int:turf_id>/photo')
def get_turf_photo(turf_id):
    try:
        turf = Turf.query.get_or_404(turf_id)
        if not turf.photo:
            abort(404)
        return send_file(
            io.BytesIO(turf.photo),
            mimetype=turf.photo_type
        )
    except Exception as e:
        logging.error(f"Photo retrieval error: {str(e)}")
        abort(500)

@app.route('/turf/<int:turf_id>/payment-qr')
def get_payment_qr(turf_id):
    try:
        turf = Turf.query.get_or_404(turf_id)
        if not turf.payment_qr:
            abort(404)
        return send_file(
            io.BytesIO(turf.payment_qr),
            mimetype='image/png'
        )
    except Exception as e:
        logging.error(f"QR code retrieval error: {str(e)}")
        abort(500)

@app.route('/confirm-platform-fee', methods=['POST'])
@login_required
def confirm_platform_fee():
    if current_user.role != 'owner':
        abort(403)
    current_user.platform_fee_paid = True
    db.session.commit()
    flash('Platform fee payment confirmed! You can now add your turf.')
    return redirect(url_for('new_turf'))


@app.route('/turf/<int:turf_id>/book', methods=['GET', 'POST'])
@login_required
def book_turf(turf_id):
    try:
        turf = Turf.query.get_or_404(turf_id)
        if request.method == 'POST':
            start_time = datetime.strptime(request.form['start_time'], '%Y-%m-%dT%H:%M')
            end_time = datetime.strptime(request.form['end_time'], '%Y-%m-%dT%H:%M')

            # Validate times
            if start_time >= end_time:
                flash('End time must be after start time')
                return redirect(url_for('book_turf', turf_id=turf_id))

            # Check for conflicts
            existing_booking = Booking.query.filter(
                Booking.turf_id == turf_id,
                Booking.start_time < end_time,
                Booking.end_time > start_time
            ).first()

            if existing_booking:
                flash('This time slot is already booked')
                return redirect(url_for('book_turf', turf_id=turf_id))

            booking = Booking(
                turf_id=turf_id,
                user_id=current_user.id,
                start_time=start_time,
                end_time=end_time,
                payment_method=request.form['payment_method'],
                payment_status='completed' if request.form['payment_method'] == 'cash' else 'pending'
            )

            try:
                db.session.add(booking)
                db.session.commit()

                if request.form['payment_method'] == 'qr':
                    return render_template('turf/book.html', turf=turf, booking=booking)

                flash('Booking confirmed!')
                return redirect(url_for('user_dashboard'))

            except Exception as e:
                logging.error(f"Booking creation error: {str(e)}")
                db.session.rollback()
                flash('An error occurred while creating the booking. Please try again.')
                return redirect(url_for('book_turf', turf_id=turf_id))

        return render_template('turf/book.html', turf=turf)

    except Exception as e:
        logging.error(f"Booking process error: {str(e)}")
        flash('An error occurred. Please try again.')
        return redirect(url_for('index'))

@app.route('/booking/<int:booking_id>/confirm-payment', methods=['POST'])
@login_required
def confirm_payment(booking_id):
    try:
        booking = Booking.query.get_or_404(booking_id)

        # Check if the booking belongs to the current user
        if booking.user_id != current_user.id:
            flash('You do not have permission to confirm this booking')
            return redirect(url_for('user_dashboard'))

        if booking.payment_status == 'completed':
            flash('This booking is already paid')
            return redirect(url_for('user_dashboard'))

        # Get the turf details for the booking
        turf = Turf.query.get_or_404(booking.turf_id)

        booking.payment_status = 'completed'
        db.session.commit()

        # The actual redirect will happen client-side after 5 seconds
        return render_template('turf/book.html', booking=booking, turf=turf)

    except Exception as e:
        logging.error(f"Payment confirmation error: {str(e)}")
        flash('An error occurred while confirming payment. Please try again.')
        return redirect(url_for('user_dashboard'))

# Admin actions
@app.route('/admin/user/<int:user_id>/delete', methods=['POST'])
@login_required
def delete_user(user_id):
    if current_user.role != 'admin':
        abort(403)
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return redirect(url_for('admin_dashboard'))